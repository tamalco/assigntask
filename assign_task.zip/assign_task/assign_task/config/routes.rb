Rails.application.routes.draw do
  devise_for :users
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  #root to: 'page_layout#home'

  root to: 'pages#index'

  get 'user_map_view', to: 'pages#user_map_view'
  get 'location/save_data', to: 'locations#save_data'
end

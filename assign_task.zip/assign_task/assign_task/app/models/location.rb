class Location < ApplicationRecord

  
 
end

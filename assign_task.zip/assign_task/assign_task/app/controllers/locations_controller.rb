class LocationsController < ApplicationController
  #before_action :authenticate_user!, only: [:secret]

  def index

  end  

  def save_data

  	locations = Location.new
  	locations.location_address = params[:location]
  	locations.latitude = params[:latitude]
  	locations.longitude = params[:longitude]
  	locations.add_publically = params[:add_publically]
    locations.user_id = params[:user_id]

  	if locations.save
  		msg = {'status' => 200 , 'success' => 'Location value saved successfully' }
  	else
  	    msg = {'status' => 300 , 'error' => 'Error is there ' }
  	end	

   FileUtils.remove_dir("public/map_show",true)
   Dir.mkdir("public/map_show")

    location_data = Location.where(user_id: current_user.id)
    if !location_data.blank?  
      File.open("public/map_show/mapdata.json","w") do |f|
        f.write(location_data.to_json)
      end
    end  

  	render :json => msg
  	
  end  
end
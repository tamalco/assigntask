class ActionsController < AuthBackendController
  before_action :set_action, only: [:show, :edit, :update, :destroy]

  # GET /actions
  # GET /actions.json
  def index
      @current_company_id = params[:company_id]
      @actions = Action.where("company_id = ?", params[:company_id])
  end

  # GET /actions/1
  # GET /actions/1.json
  def show
  end

  # GET /actions/new
  def new
    @current_company_id = @current_user.company_id
    @action = Action.new

    @action.previous_step_id = params[:previous_step_id]
  end

  # GET /actions/1/edit
  def edit
      @current_company_id = @current_user.company_id
  end

  # POST /actions
  # POST /actions.json
  def create

    @current_company_id = @current_user.company_id
    @action = Action.new(action_params)

    respond_to do |format|
      if @action.save
        format.html { head :no_content }
        format.json { render :show, status: :created, location: @action }
      else
        format.html { render :new }
        format.json { render json: @action.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /actions/1
  # PATCH/PUT /actions/1.json
  def update
    respond_to do |format|
      if @action.update(action_params)
        format.html { head :no_content }
        format.json { render :show, status: :ok, location: @action }
      else
        format.html { render :edit }
        format.json { render json: @action.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /actions/1
  # DELETE /actions/1.json
  def destroy
    

    if @action.role_id != 11
      @action.destroy
    else
      geodynamicAction = GeodynamicAction.where(action_id: @action.id).first
      if !geodynamicAction.nil?
        geodynamicActionval = GeodynamicActionsItemValue.where(id: geodynamicAction.id).first
        if !geodynamicActionval.nil?
           GeodynamicActionsItemValue.find(geodynamicActionval.id).destroy
           GeodynamicAction.find(geodynamicAction.id).destroy
        end  
       
      end  
      @action.destroy
    end  
    
    respond_to do |format|
      format.html { head :no_content }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_action
      @action = Action.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def action_params
     params.require(:actions).permit(:company_id, :name, :role_id, :previous_step_id, :next_step_id, :position, :pre_form_id, :post_form_id, :autoexecute, :notify_dispatcher, :notify_provider, :notify_client, :icon)
    end
end
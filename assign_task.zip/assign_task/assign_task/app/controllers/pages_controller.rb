class PagesController < ApplicationController
  before_action :authenticate_user!, only: [:secret]

  def index

  end  

  def user_map_view
    if !current_user.nil?
      render :layout => "dashboard"
    end
  end  
end
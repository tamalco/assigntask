class Users < ActiveRecord::Migration[5.0]
  def change
  	add_column :users, :latitude, :decimal, :precision => 16, :scale => 13
  	add_column :users, :longitude,:decimal, :precision => 16, :scale => 13
  	add_column :users, :add_publically, :tinyint, :limit => 1
  	add_column :users, :created_at, :datetime
  	add_column :users, :updated_at, :datetime  	
  end
end

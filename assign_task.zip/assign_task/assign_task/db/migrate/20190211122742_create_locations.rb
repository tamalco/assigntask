class CreateLocations < ActiveRecord::Migration[5.0]
  def change
    create_table :locations do |t|
      t.string :location_address
      t.string :latitude
      t.string :longitude
      t.integer :add_publically
    end
  end
end
